#' @name install.R
#' @title Installation Script for `policy_optimizer` package functions
#' @description Script for test install of `policy_optimizer` package functions.



